SELECT * FROM membertbl;

SELECT memberID, memberName FROM membertbl;

SELECT memberID, memberName FROM membertbl
WHERE UPPER(memberid) = 'DANG';